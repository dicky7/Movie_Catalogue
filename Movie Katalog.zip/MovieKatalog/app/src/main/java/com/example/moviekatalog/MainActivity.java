package com.example.moviekatalog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Movie_Adapter adapter;
    private String[] dataName;
    private  String[] dataDesc;
    private TypedArray dataPhoto;
    private ArrayList<Movie>movies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.lv_list);
        adapter = new Movie_Adapter(this);
        listView.setAdapter(adapter);
        prepare();
        addItem();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, Detail.class);
                intent.putExtra(Detail.EXTRA_MOVIE, movies.get(position));
                startActivity(intent);
                Toast.makeText(MainActivity.this, movies.get(position).getName(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void  prepare(){
        dataName = getResources().getStringArray(R.array.data_name);
        dataDesc = getResources().getStringArray(R.array.data_desc);
        dataPhoto = getResources().obtainTypedArray(R.array.data_photto);
    }

    private void  addItem(){
        movies = new ArrayList<>();
        for (int i =0; i<dataName.length; i++){
            Movie movie = new Movie();
            movie.setPhoto(dataPhoto.getResourceId(i, -1));
            movie.setName(dataName[i]);
            movie.setDescription(dataDesc[i]);
            movies.add(movie);
        }
        adapter.setMovies(movies);
    }
}
