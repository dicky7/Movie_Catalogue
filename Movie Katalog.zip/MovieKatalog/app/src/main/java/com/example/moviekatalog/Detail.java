package com.example.moviekatalog;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.Objects;

public class Detail extends AppCompatActivity implements View.OnClickListener {
    public  static final  String EXTRA_MOVIE = "extra_MOVIE";
    TextView nama_detail;
    TextView desc_detail;
    ImageView img_detail;
    ImageButton favorite;
    ImageButton boomark;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setActionBarTittle();

        nama_detail = findViewById(R.id.nama_detail);
        desc_detail = findViewById(R.id.desc_detail);
        img_detail = findViewById(R.id.img_detail);
        favorite = findViewById(R.id.favorit);
        favorite.setOnClickListener(this);
        boomark = findViewById(R.id.boomark);
        boomark.setOnClickListener(this);
        Movie movie = getIntent().getParcelableExtra(EXTRA_MOVIE);


        assert  movie != null;
        String namaMovie = movie.getName();
        nama_detail.setText(namaMovie);
        Glide.with(this)
                .load(movie.getPhoto())
                .apply(new RequestOptions())
                .into(img_detail);
        String descMovie = movie.getDescription();
        desc_detail.setText(descMovie);


    }

    private void setActionBarTittle() {
        Objects.requireNonNull(getSupportActionBar()).setTitle("Movie");

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.favorit:
                Toast.makeText(Detail.this, "Favorite", Toast.LENGTH_SHORT ).show();
                break;

            case  R.id.boomark:
                Toast.makeText(Detail.this, "Boomarked", Toast.LENGTH_SHORT).show();
                break;
        }

    }
}
